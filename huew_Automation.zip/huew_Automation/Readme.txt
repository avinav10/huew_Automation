**********Instructions to run the script***************

This Project contains code in python 3 and supported IDEs like pyCharm and must install selenium and pytest components.

This Project contains 7 packages-

1. conftest.py
2. ui-
	a)home
	b)profile
3)utils-
	a)create_driver
	b)subprocessupload
4)test-
	a)test_infilect
	b)login_details.json


To run subprocessupload, one more executable file is needed i.e. upload.exe
You need to go to subprocessupload.py under utils package and provide appropriate path in 'call_sub'
The upload.exe will take the photo from filepath-
C:/Users/pic.jpg
So please place the .jpg file "exactly" in this location.

provide 'login details' in 'login_details.json' file. It required user_name and password.

for validation, the screenshot is placed under test\screenshot\




To run the Automation script, go to the terminal and write below command

python -m pytest <relative path of test_infilect.py>

or

python -m pytest <relative path of test_infilect.py> --type=chrome --env=local


Example:
python -m pytest test/test_infilect.py


Note: For any doubts and queries, contact me @ +91-8904752092 or avinavdas@outlook.com





 