from lib.ui.home import HomePage
from lib.ui.profile import ProfilePage
from lib.utils import create_driver
from selenium.webdriver.common.keys import Keys
from lib.utils import subprocessupload
import unittest
import time
import json

class TestInfilect(unittest.TestCase):

    def setUp(self):
        self.subprocess = subprocessupload.subprocess_call()
        self.driver = create_driver.get_browser_instance()
        self.home = HomePage(self.driver)
        self.profile = ProfilePage(self.driver)

    def tearDown(self):
        self.driver.close()


    def test_Infilect(self):

        data = json.load(open('./test/login_details.json'))

    #go to home page & click on 'You' button
        self.home.wait_for_home_page_to_load()
        self.home.get_you_button().click()

        time.sleep(5)

    # Click on Login using Google
        self.profile.wait_for_profile_page_to_load()
        self.profile.get_login_using_google_button().click()

    #switch window from parent to child
        windows_ids = self.driver.window_handles
        self.parent_id = windows_ids[0]
        self.child_id = windows_ids[1]
        time.sleep(5)
        self.driver.switch_to.window(self.child_id)
        self.profile.wait_for_google_sign()

    #Enter username and password

        self.profile.username_google().send_keys(data['gmail_info']['user_name'], Keys.ENTER)

        self.profile.password_google().send_keys(data['gmail_info']['password'],Keys.ENTER)

        time.sleep(5)

    #switch window from child to parent window
        self.driver.switch_to.window(self.parent_id)
        time.sleep(5)

    #click on discover button
        self.profile.get_discover_button().click()
        time.sleep(5)

    #click to upload a photo
        self.profile.get_file_upload().click()
        time.sleep(10)

    #click on submit and save button
        self.profile.get_save_click().click()
        time.sleep(40)
        self.profile.get_save_click().click()
        time.sleep(5)

    #click on click here at botton
        self.profile.get_click_here_bottom().click()
        time.sleep(5)

    # validation
        self.driver.get_screenshot_as_file('./test/screenshot/file.png')


