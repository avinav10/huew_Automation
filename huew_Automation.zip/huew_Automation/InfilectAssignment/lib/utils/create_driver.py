from selenium.webdriver import Chrome,Firefox,Ie

import pytest

def get_browser_instance():

    browser_info = pytest.config.option.type.lower()

    url = pytest.config.option.env.lower()

    if browser_info == 'chrome':
        driver = Chrome('./browsers_exe/chromedriver.exe')

    driver.maximize_window()
    driver.implicitly_wait(30)

    if url == 'local':
        driver.get('https://huew.co/')

    return driver
