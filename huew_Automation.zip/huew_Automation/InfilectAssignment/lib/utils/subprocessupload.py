import subprocess


def subprocess_call():
    call_sub = subprocess.Popen([r"C:/Users/adas/Desktop/CC/upload.exe"])
    return call_sub