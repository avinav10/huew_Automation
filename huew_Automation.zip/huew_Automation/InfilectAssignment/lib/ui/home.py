from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
import time

class HomePage():

    def __init__(self,driver):
        self.driver = driver

    def wait_for_home_page_to_load(self):
        time.sleep(5)

        wait =WebDriverWait(self.driver,50)
        wait.until(expected_conditions.visibility_of(self.driver.find_element_by_xpath("(//div[@class='desktop-menu-icon-text'])[5]")))

    def get_you_button(self):

        try:

            element = self.driver.find_element_by_xpath("(//div[@class='desktop-menu-icon-text'])[5]")
            return element

        except:
            return None
