from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

class ProfilePage():

    def __init__(self,driver):
        self.driver = driver

    def wait_for_profile_page_to_load(self):
        wait =WebDriverWait(self.driver,30)
        wait.until(expected_conditions.visibility_of(self.driver.find_element_by_class_name("login-buttons-container")))

    def get_login_using_google_button(self):

        try:
            element = self.driver.find_element_by_xpath("//img[contains(@ng-click,'google')]")
            return element

        except:
            return None

    def wait_for_google_sign(self):
        wait = WebDriverWait(self.driver,30)
        wait.until(expected_conditions.visibility_of(self.driver.find_element_by_name("identifier")))

    def username_google(self):

        try:

            element = self.driver.find_element_by_name("identifier")
            return element

        except:
            return None

    def password_google(self):

        try:
            element = self.driver.find_element_by_name("password")
            return element

        except:
            return None

    def get_discover_button(self):
        try:
            element = self.driver.find_element_by_xpath("(//div[@class='desktop-menu-icon-text'])[1]")
            return element
        except:
            return None



    def get_file_upload(self):

        try:
            element = self.driver.find_element_by_name("file")
            return element

        except:
            return None

    def get_save_click(self):

        try:
            element = self.driver.find_element_by_xpath("(//button)[1]")
            return element
        except:
            return None

    def get_click_here_bottom(self):

        try:
            element = self.driver.find_element_by_xpath("//a[@ng-controller='UserInspirationInteractionCtrl']")
            return element

        except:
            return None
